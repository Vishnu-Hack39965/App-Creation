# Rakshapal Singh Library ERP — Full App

## Files in this project

```
library-app/
├── web/
│   └── index.html              ← Your complete website (deploy to Firebase Hosting)
└── android/
    └── app/
        ├── build.gradle        ← Android dependencies (minSdk 29 = Android 10+)
        └── src/main/
            ├── AndroidManifest.xml     ← Deep link registrations
            ├── res/layout/
            │   └── activity_main.xml  ← Full screen WebView layout
            └── java/com/rakshapal/library/
                └── MainActivity.kt    ← All app logic
```

---

## What changed from your original code

### Website (index.html)
1. `connectToWifi()` — now fires deep link `mylibraryapp://wifi?ssid=...&pass=...`
   Password comes from Firebase, goes to app silently. Never shown on screen.

2. `verifyLeave()` — now fires deep link `mylibraryapp://forgetwifi`
   instead of `AndroidBridge.forgetWifi()`. Consistent with deep link approach.

3. Removed duplicate `connectToWifi()` definition (was defined twice in your original).

### Android (MainActivity.kt)
- Loads your website in a full-screen WebView
- Intercepts `mylibraryapp://wifi` → connects to WiFi silently
- Intercepts `mylibraryapp://forgetwifi` → removes WiFi suggestion, device disconnects
- Intercepts `upi://` links → opens PhonePe/GPay correctly
- Intercepts Google OAuth links → opens in Custom Chrome Tab so sign-in works
- All other links stay inside WebView

---

## How WiFi password rotation works

1. You go to Manage → Wi-Fi tab in your app
2. Type new SSID and new password → tap Update Wi-Fi
3. Saved to Firebase `settings/wifi` document
4. Next time any member taps Connect to Internet:
   - Fresh password is fetched from Firebase
   - Sent to their app via deep link
   - Device connects with new password
   No app update needed. Ever.

---

## App deletion behaviour

When a member deletes the app, Android 10+ automatically removes
all WiFi network suggestions made by that app. The device disconnects
from library WiFi immediately. This is built into Android — no code needed.

---

## Payment flow (manual — by design)

```
Member fills shift + days
        ↓
App calculates amount
        ↓
UPI app opens (PhonePe/GPay)
        ↓
Member pays
        ↓
Signal appears in YOUR admin panel (Manage → Signals)
        ↓
You tap VERIFY after checking your UPI app
        ↓
Member's days are added automatically
```

This is safe and appropriate for a library. No transaction fees.

---

## How to deploy

### Website → Firebase Hosting
```bash
npm install -g firebase-tools
firebase login
firebase init hosting
# set public directory to: web
firebase deploy
```

### Android App → Android Studio
1. Open android/ folder in Android Studio
2. Sync Gradle
3. Build → Generate Signed APK
4. Install on device or publish to Play Store

---

## Firebase Firestore structure

```
/users/{uid}
  name, father, phone, address, email, photo
  isOnline, joinDate, joinDateISO
  totalPaidDays, history[]

/signals/{id}
  type: ADMISSION | EXIT | PAYMENT
  uid, name, phone, otp, timestamp, expiresAt

/settings/wifi
  ssid: "Library-WiFi-Name"
  pass: "YourPassword"     ← only admin can write, only logged-in users can read
```

### Firebase Security Rules (set these in Firebase Console)
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{uid} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
      allow read: if request.auth.token.email == "c.commando822@gmail.com";
      allow write: if request.auth.token.email == "c.commando822@gmail.com";
    }
    match /signals/{id} {
      allow read, write: if request.auth != null;
    }
    match /settings/wifi {
      allow read: if request.auth != null;
      allow write: if request.auth.token.email == "c.commando822@gmail.com";
    }
  }
}
```

---

## Requirements
- Android 10 (API 29) or higher — required for Network Suggestion API
- Internet permission granted
- Location permission granted (required by Android for WiFi management)
